<!-- resources/views/layouts/dashboard.blade.php -->
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <style>
@keyframes typing {
    from { width: 0 }
    to { width: 100% }
}
@keyframes blink {
    50% { border-color: transparent }
}

.typing-effect {
    overflow: hidden;
    border-right: 1px solid white;
    white-space: nowrap;
    width: 0;
    animation:
        typing 2s steps(10, end) forwards,
        blink 0.7s step-end infinite;
}
</style>
</head>
<body class="bg-gray-800 text-white">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-black flex flex-col justify-between">
            <div>
                <!-- LOGO -->
                <div class="p-6 text-white text-2xl font-bold tracking-wide">
    <span class="typing-effect">&lt;SNAP/&gt;</span>
</div>

                <!-- Navegação -->
                <nav class="px-6 space-y-4">
                    <a href="#" class="block py-2 px-4 rounded hover:bg-gray-700">Dashboard</a>

                    <!-- Gestão Dropdown -->
                    <div x-data="{ open: false }" class="space-y-1">
                        <button @click="open = !open" class="w-full text-left py-2 px-4 rounded hover:bg-gray-700 flex justify-between items-center">
                            Gestão
                            <svg class="w-4 h-4 transform transition-transform" :class="{ 'rotate-180': open }" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </button>
                        <div x-show="open" class="pl-4 space-y-1">
                            <a href="#" class="block py-2 px-2 rounded hover:bg-gray-700">Gestão de Material</a>
                            <a href="#" class="block py-2 px-2 rounded hover:bg-gray-700">Gestão de Colaboradores</a>
                        </div>
                    </div>

                    <a href="#" class="block py-2 px-4 rounded hover:bg-gray-700">Eventos</a>
                    <a href="#" class="block py-2 px-4 rounded hover:bg-gray-700">Calendário</a>
                </nav>
            </div>

            <!-- Logout -->
            <div class="p-6">
                <a href="<?php echo e(route('logout')); ?>" class="block py-2 px-4 bg-red-600 hover:bg-red-700 rounded text-center">
                    Logout
                </a>
            </div>
        </aside>

        <!-- Conteúdo Principal -->
        <main class="flex-1 p-10 overflow-y-auto">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <script src="//unpkg.com/alpinejs" defer></script>
</body>
</html>
<?php /**PATH C:\Users\Cesae\Desktop\TrabalhoFinalSDEV\TrabalhoFinalSDEV\resources\views/dashboard.blade.php ENDPATH**/ ?>