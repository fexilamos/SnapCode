<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>SNAP</title>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.jsx'); ?>
</head>
<body>
    <div id="app"></div>
</body>
</html>
<?php /**PATH C:\Users\Cesae\Desktop\TrabalhoFinalSDEV\TrabalhoFinalSDEV\resources\views/teste.blade.php ENDPATH**/ ?>