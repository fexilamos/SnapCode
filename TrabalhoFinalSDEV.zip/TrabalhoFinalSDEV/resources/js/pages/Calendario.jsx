import React from 'react';
import Layout from '../components/Layout';

export default function Calendario() {
    return (
        <Layout>
            <h1>Calendário</h1>
            <p>Conteúdo da página Calendário.</p>
        </Layout>
    );
}
