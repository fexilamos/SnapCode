import React from 'react';
import Layout from '../components/Layout';

export default function Eventos() {
    return (
        <Layout>
            <h1>Eventos</h1>
            <p>Conteúdo da página Eventos.</p>
        </Layout>
    );
}
