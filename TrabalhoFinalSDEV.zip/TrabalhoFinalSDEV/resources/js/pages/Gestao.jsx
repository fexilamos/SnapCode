import React from 'react';
import Layout from '../components/Layout';

export default function Gestao() {
    return (
        <Layout>
            <h1>Gestão</h1>
            <p>Conteúdo da página Gestão.</p>
        </Layout>
    );
}
