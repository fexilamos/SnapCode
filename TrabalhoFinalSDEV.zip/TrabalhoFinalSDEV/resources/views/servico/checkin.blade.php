<div>
    <!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
</div>
